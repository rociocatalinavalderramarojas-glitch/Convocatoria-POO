package com.academico.docentes.docente.service;

import com.academico.docentes.common.exception.DatoDuplicadoException;
import com.academico.docentes.common.exception.RecursoNoEncontradoException;
import com.academico.docentes.docente.domain.Docente;
import com.academico.docentes.docente.dto.DocenteRequest;
import com.academico.docentes.docente.dto.DocenteResponse;
import com.academico.docentes.docente.mapper.DocenteMapper;
import com.academico.docentes.docente.repository.DocenteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class DocenteServiceImpl implements DocenteService {

    private final DocenteRepository docenteRepository;
    private final DocenteMapper docenteMapper;

    public DocenteServiceImpl(DocenteRepository docenteRepository, DocenteMapper docenteMapper) {
        this.docenteRepository = docenteRepository;
        this.docenteMapper = docenteMapper;
    }

    @Override
    @Transactional
    public DocenteResponse registrar(DocenteRequest request) {
        verificarUnicidad(request.dni().trim(), request.correo().trim().toLowerCase(), null);
        Docente nuevo = docenteMapper.toEntity(request);
        Docente guardado = docenteRepository.save(nuevo);
        return docenteMapper.toResponse(guardado);
    }

    @Override
    public List<DocenteResponse> listarTodos() {
        return docenteRepository.findAll()
                .stream()
                .map(docenteMapper::toResponse)
                .toList();
    }

    @Override
    public DocenteResponse buscarPorId(Long id) {
        Docente docente = obtenerEntidadPorId(id);
        return docenteMapper.toResponse(docente);
    }

    @Override
    @Transactional
    public DocenteResponse actualizar(Long id, DocenteRequest request) {
        Docente existente = obtenerEntidadPorId(id);
        verificarUnicidad(request.dni().trim(), request.correo().trim().toLowerCase(), id);
        docenteMapper.updateEntity(existente, request);
        Docente actualizado = docenteRepository.save(existente);
        return docenteMapper.toResponse(actualizado);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Docente existente = obtenerEntidadPorId(id);
        docenteRepository.delete(existente);
    }

    private Docente obtenerEntidadPorId(Long id) {
        return docenteRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException(
                        "No se encontró ningún docente con el ID: " + id));
    }

    private void verificarUnicidad(String dni, String correo, Long idActual) {
        docenteRepository.findByDni(dni)
                .filter(d -> !d.getId().equals(idActual))
                .ifPresent(d -> {
                    throw new DatoDuplicadoException("Ya se encuentra registrado un docente con el DNI: " + dni);
                });

        docenteRepository.findByCorreo(correo)
                .filter(d -> !d.getId().equals(idActual))
                .ifPresent(d -> {
                    throw new DatoDuplicadoException("Ya se encuentra registrado un docente con el correo: " + correo);
                });
    }
}
