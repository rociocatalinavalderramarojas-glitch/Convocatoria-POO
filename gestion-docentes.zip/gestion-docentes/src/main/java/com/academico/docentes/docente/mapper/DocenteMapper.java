package com.academico.docentes.docente.mapper;

import com.academico.docentes.docente.domain.Docente;
import com.academico.docentes.docente.dto.DocenteRequest;
import com.academico.docentes.docente.dto.DocenteResponse;
import org.springframework.stereotype.Component;

@Component
public class DocenteMapper {

    public Docente toEntity(DocenteRequest request) {
        return new Docente(
                request.nombres().trim(),
                request.apellidos().trim(),
                request.dni().trim(),
                request.correo().trim().toLowerCase(),
                request.fechaNacimiento()
        );
    }

    public void updateEntity(Docente docente, DocenteRequest request) {
        docente.setNombres(request.nombres().trim());
        docente.setApellidos(request.apellidos().trim());
        docente.setDni(request.dni().trim());
        docente.setCorreo(request.correo().trim().toLowerCase());
        docente.setFechaNacimiento(request.fechaNacimiento());
    }

    public DocenteResponse toResponse(Docente docente) {
        return new DocenteResponse(
                docente.getId(),
                docente.getNombres(),
                docente.getApellidos(),
                docente.getDni(),
                docente.getCorreo(),
                docente.getFechaNacimiento(),
                docente.getCreadoEn(),
                docente.getActualizadoEn()
        );
    }
}
