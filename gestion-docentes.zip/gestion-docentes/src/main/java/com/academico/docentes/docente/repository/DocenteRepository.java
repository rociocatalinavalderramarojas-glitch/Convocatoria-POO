package com.academico.docentes.docente.repository;

import com.academico.docentes.docente.domain.Docente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DocenteRepository extends JpaRepository<Docente, Long> {

    Optional<Docente> findByDni(String dni);

    Optional<Docente> findByCorreo(String correo);
}
