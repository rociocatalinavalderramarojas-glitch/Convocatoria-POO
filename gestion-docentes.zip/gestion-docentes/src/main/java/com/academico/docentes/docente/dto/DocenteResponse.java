package com.academico.docentes.docente.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record DocenteResponse(
        Long id,
        String nombres,
        String apellidos,
        String dni,
        String correo,
        LocalDate fechaNacimiento,
        LocalDateTime creadoEn,
        LocalDateTime actualizadoEn
) {
}
