package com.academico.docentes.docente.service;

import com.academico.docentes.docente.dto.DocenteRequest;
import com.academico.docentes.docente.dto.DocenteResponse;

import java.util.List;

public interface DocenteService {

    DocenteResponse registrar(DocenteRequest request);

    List<DocenteResponse> listarTodos();

    DocenteResponse buscarPorId(Long id);

    DocenteResponse actualizar(Long id, DocenteRequest request);

    void eliminar(Long id);
}
