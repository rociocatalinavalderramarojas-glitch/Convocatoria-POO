package com.academico.docentes.docente.service;

import com.academico.docentes.common.exception.DatoDuplicadoException;
import com.academico.docentes.common.exception.RecursoNoEncontradoException;
import com.academico.docentes.docente.domain.Docente;
import com.academico.docentes.docente.dto.DocenteRequest;
import com.academico.docentes.docente.dto.DocenteResponse;
import com.academico.docentes.docente.mapper.DocenteMapper;
import com.academico.docentes.docente.repository.DocenteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DocenteServiceImplTest {

    @Mock
    private DocenteRepository docenteRepository;

    private DocenteMapper docenteMapper;
    private DocenteServiceImpl docenteService;

    @BeforeEach
    void setUp() {
        docenteMapper = new DocenteMapper();
        docenteService = new DocenteServiceImpl(docenteRepository, docenteMapper);
    }

    @Test
    void registrarDocenteExitoso() {
        DocenteRequest request = new DocenteRequest(
                "Laura", "Gómez", "1098765", "laura@correo.com", LocalDate.of(1990, 5, 14)
        );
        when(docenteRepository.findByDni("1098765")).thenReturn(Optional.empty());
        when(docenteRepository.findByCorreo("laura@correo.com")).thenReturn(Optional.empty());
        when(docenteRepository.save(any(Docente.class))).thenAnswer(inv -> {
            Docente d = inv.getArgument(0);
            d.setId(1L);
            return d;
        });

        DocenteResponse response = docenteService.registrar(request);

        assertEquals(1L, response.id());
        assertEquals("Laura", response.nombres());
        assertEquals("laura@correo.com", response.correo());
        verify(docenteRepository).save(any(Docente.class));
    }

    @Test
    void registrarConDniDuplicadoLanzaExcepcion() {
        Docente existente = new Docente("Carlos", "Ruiz", "1098765", "carlos@correo.com", LocalDate.of(1985, 3, 10));
        existente.setId(2L);
        DocenteRequest request = new DocenteRequest(
                "Laura", "Gómez", "1098765", "laura@correo.com", LocalDate.of(1990, 5, 14)
        );
        when(docenteRepository.findByDni("1098765")).thenReturn(Optional.of(existente));

        assertThrows(DatoDuplicadoException.class, () -> docenteService.registrar(request));
        verify(docenteRepository, never()).save(any());
    }

    @Test
    void buscarPorIdInexistenteLanzaExcepcion() {
        when(docenteRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNoEncontradoException.class, () -> docenteService.buscarPorId(99L));
    }

    @Test
    void listarTodosDevuelveListaMapeada() {
        Docente d1 = new Docente("Ana", "Pérez", "111", "ana@correo.com", LocalDate.of(1988, 1, 1));
        d1.setId(1L);
        when(docenteRepository.findAll()).thenReturn(List.of(d1));

        List<DocenteResponse> resultado = docenteService.listarTodos();

        assertEquals(1, resultado.size());
        assertEquals("Ana", resultado.get(0).nombres());
    }
}
