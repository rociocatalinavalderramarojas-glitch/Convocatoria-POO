# API REST - Gestión de Docentes

Servicio web RESTful construido con **Spring Boot**, **Spring Data JPA** y **MySQL** para la administración de docentes.

## Arquitectura y Estructura del Proyecto

El proyecto sigue una organización modular orientada al dominio (*package-by-feature*) con separación estricta entre entidades de persistencia, objetos de transferencia de datos (DTOs) y manejo centralizado de excepciones:

```
com.academico.docentes
├── common/
│   └── exception/          # Excepciones de dominio, ErrorResponse y GlobalExceptionHandler
├── config/                 # Configuración de OpenAPI / Swagger
└── docente/
    ├── controller/         # Endpoints REST (/api/v1/docentes)
    ├── domain/             # Entidad JPA Docente
    ├── dto/                # Records inmutables (DocenteRequest, DocenteResponse)
    ├── mapper/             # Conversión entre entidad y DTOs
    ├── repository/         # Repositorio JpaRepository
    └── service/            # Interfaz DocenteService e implementación transaccional
```

## Requisitos
- JDK 21 o superior
- MySQL 8+

## Configuración
1. Copiar `src/main/resources/db-secrets.properties.example` como `db-secrets.properties` y completar `DB_USER` y `DB_PASSWORD`.
2. La base de datos `gestion_docentes_db` se creará automáticamente si no existe (`createDatabaseIfNotExist=true`) y Hibernate generará/actualizará la tabla `docentes`.
3. Ejecutar la aplicación:
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```

## Documentación Swagger
Disponible en: `http://localhost:8085/swagger-ui/index.html`

## Endpoints (`/api/v1/docentes`)
| Método | Ruta | Descripción | Código |
|---|---|---|---|
| `GET` | `/api/v1/docentes` | Listar todos los docentes | `200 OK` |
| `GET` | `/api/v1/docentes/{id}` | Consultar un docente por ID | `200 OK` |
| `POST` | `/api/v1/docentes` | Registrar un nuevo docente | `201 Created` |
| `PUT` | `/api/v1/docentes/{id}` | Actualizar un docente existente | `200 OK` |
| `DELETE` | `/api/v1/docentes/{id}` | Eliminar un docente | `204 No Content` |
